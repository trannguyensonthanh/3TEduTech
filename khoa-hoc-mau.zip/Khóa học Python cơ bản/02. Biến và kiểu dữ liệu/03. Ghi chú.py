# Ví dụ về biến trong Python
ten = "Sơn Thành"
tuoi = 21
diem = 8.5
dang_hoc = True

print(f"{ten} - {tuoi} tuoi - diem {diem}")
