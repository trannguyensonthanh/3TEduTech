# Khóa học Python cơ bản

Khóa học đưa bạn từ con số 0 tới chỗ viết được chương trình Python đầu tiên.

Nội dung xoay quanh ba phần: cài đặt môi trường, làm quen cú pháp, và luyện
tập qua bài tập nhỏ. Không yêu cầu kiến thức lập trình trước đó.
