Chương mở đầu: hiểu Python là gì
và cài đặt được môi trường làm việc trên máy của bạn.
